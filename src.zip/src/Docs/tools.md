---
title: Tools module
authors: Romain Bulteau
geometry: margin=1cm
---

```
#!/usr/bin/env python

import Sequence
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
import subprocess

#--------------------------
# QUALITY TREATMENT TOOL
#--------------------------
	#Allows for 1 base to be bad if the next is over the treshold
	
def quality_treatment(path2file,path2output,threshold):
	
	path2file = path2file
	path2output = path2output
	sequences = fastq2Sequence(path2file)
    	
    	for ind_seq in sequences :
    		i=0
    		j=0
    		newQual = []
    		
    		for qual_pb in ind_seq.get_QUALITY():
    											
    			if i+1 < len(ind_seq.get_QUALITY()):
	    			if qual_pb >= threshold or ind_seq.get_QUALITY()[i+1]>=threshold: 
	    				newQual.append(qual_pb)
	    				j += 1
	    			elif j > 0 :
	    				break
	    			
	    			i += 1
    		if i == j:
    			newSeq = ind_seq.get_SEQUENCE()[:i] 		    			
    		elif j != 0:
    			newSeq = ind_seq.get_SEQUENCE()[i-j-1:i]
    			
    		ind_seq.set_SEQUENCE(newSeq)
    		ind_seq.set_QUALITY(newQual)
    		
    	write_fastq(path2output, sequences)

#--------------------------
# LENGTH TREATMENT TOOL
#--------------------------

def length_treatment(path2file, path2output, threshold):
		
	sequences = fastq2Sequence(path2file)
	newSeqs = []
	for ind_seq in sequences:
		if ind_seq.get_LENGTH()>=threshold:
			newSeqs.append(ind_seq)			
	write_fastq(path2output, newSeqs)

#--------------------------
# R GRAPH GEN TOOL
#--------------------------

def format_files(path2input, path2output, ftype):
	
	sequences = fastq2Sequence(path2input)
	
	if ftype == 'length':
		path2output+='_length.txt'
		OUT=open(path2output,'w')
		fwrite=""
		for ind_seq in sequences:
			fwrite+=ind_seq.get_ID()+"\t"+str(ind_seq.get_LENGTH())+"\n"
		OUT.write(fwrite)
	elif ftype == 'quality':
		path2output+='_quality.txt'
		OUT=open(path2output,'w')
		ml=max_length(sequences)
		
		for ind_seq in sequences:
			fQual = ind_seq.get_QUALITY()
			while len(fQual) < ml:
				fQual.append('NA')
				#print str(len(fQual))+" / "+str(ml)
			fwrite=""
			for ind_qual in fQual:
				fwrite+=str(ind_qual)+"\t"
			fwrite+="\n"
			OUT.write(fwrite)
	
	OUT.close()	
	
def r_call(path2script, path2input, path2output):
	
	subprocess.call(['Rscript', path2script, path2input, path2output])

#--------------------------
# MISC FUNCTIONS
#--------------------------

def max_length(sequences):
	
	ml=0
	for ind_seq in sequences:
		if ind_seq.get_LENGTH() >= ml:
			ml = ind_seq.get_LENGTH()
	return ml

def write_fastq(path2output,seqs):
	sequences_rec = []
	for ind_seq in seqs :
    		sequences_rec.append(sequence2SeqRecord(ind_seq))
    	SeqIO.write(sequences_rec, path2output, "fastq")

def fastq2fasta(path2input,path2output):
	sequences_rec = []
	for seqrec_obj in SeqIO.parse(path2input,"fastq") :
    		sequences_rec.append(seqrec_obj)
    	SeqIO.write(sequences_rec, path2output, "fasta")

def fastq2Sequence(path2file):

	sequences = []
	for bioSeqRecord_obj in SeqIO.parse(path2file,"fastq"):
    		sequences.append(Sequence.Sequence(bioSeqRecord_obj))
    	return sequences
	    		
def sequence2SeqRecord(seq_obj):

	seqRecord_obj = SeqRecord(seq_obj.get_SEQUENCE(),
						id = seq_obj.get_ID())

	seqRecord_obj.letter_annotations['phred_quality'] = seq_obj.get_QUALITY()
	return seqRecord_obj
	
```	
